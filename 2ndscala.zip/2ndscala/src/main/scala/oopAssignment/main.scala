package oopAssignment
object main {
  def main(args: Array[String]): Unit =
  {
    val object1=new Person(26,"test")
    val object2=new Person(25,"test")

    if ((object1.Name)equals(object2.Name))
    {
      if((object1.Age)<(object2.Age))
        println("true")
      else
        println("false")
    }
    else
      {
        if ((object1.Name.length()) < (object2.Name.length()))
          println("true")
        else
          println("false")
      }
  }
}