package oopAssignment

trait Ordered {
  def person(): Unit;
}
