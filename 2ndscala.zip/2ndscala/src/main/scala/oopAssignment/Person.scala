package oopAssignment

case class Person(Age: Int,Name: String)
{

}
